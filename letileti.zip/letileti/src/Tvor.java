public abstract class Tvor {
    private boolean isSleeping;
    private int x, y ,z;

    public void move(int dx, int dy, int dz) {
        if (isSleeping) {
            System.out.println("Nepohybuje sa, spi.");
        } else {
            x += dx;
            y += dy;
            z += dz;
            System.out.println("Nespi, pohybuje sa " + dx + " " + dy + " " + dz);

        }
    }

    public void sleep(){
        isSleeping = true;
    }
    public void wakeup(){
        isSleeping = false;
    }
    public boolean isSleeping() {
        return isSleeping;
    }

}
