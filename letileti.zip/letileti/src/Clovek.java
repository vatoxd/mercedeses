import java.util.Date;

public class Clovek extends Tvor implements speakable{
    private String rasa;
    private Date datum_vzniku;
    private Pohlavie pohlavie;

    public Clovek(String rasa, Date datum_vzniku, Pohlavie pohlavie) {
        this.rasa = rasa;
        this.datum_vzniku = datum_vzniku;
        this.pohlavie = pohlavie;
    }

    @Override
    public void move(int dx, int dy, int dz){
        if (isSleeping()){
            System.out.println("Nemoze sa hybat, spi.");
        } else {
            super.move(dx, dy, dz);
            System.out.println("Tvor sa pohybuje " + dx + ", " + dy + ", " + dz);
        }
    }

    @Override
    public void speak(String text){
        System.out.println("Adam hovori: " + text);
    }
}
