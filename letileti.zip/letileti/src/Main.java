import java.util.*;
import java.util.List;
import java.util.Date;

public class Main {

    static Vtak[] vtaky = new Vtak[100];
    static Raja[] raje =  new Raja[100];

    public static void main(String[] args) {
        Zem zem = new Zem();
        Date today = new Date();
        Clovek adam = new Clovek("Zlta", today, Pohlavie.MALE);

        zem.addTvor(adam);
        adam.speak("Je tu pusto. Ani vtacika, letacika");

        for (int i = 0; i < 100 ; i++){
            vtaky[i] = new Vtak();
            raje[i] = new Raja();
        }

        SynchronyFly<Vtak> vtakyFly = new SynchronyFly<>(List.of(vtaky));
        SynchronyFly<Raja> rajeFly = new SynchronyFly<>(List.of(raje));

        vtakyFly.startFlying();
        rajeFly.startFlying();
    }
}