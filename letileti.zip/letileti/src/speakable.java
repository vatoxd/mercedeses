public interface speakable {
    public void speak(String text);
}
