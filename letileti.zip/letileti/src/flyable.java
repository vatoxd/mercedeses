public interface flyable {
    public void fly();
}
