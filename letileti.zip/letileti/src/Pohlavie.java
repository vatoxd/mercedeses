public enum Pohlavie {
    MALE,
    FEMALE
}
