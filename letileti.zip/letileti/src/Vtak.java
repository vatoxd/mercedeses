public class Vtak extends Tvor implements flyable{
    @Override
    public void fly() {
        if (!isSleeping()){
            mavatkridlami();
        } else {
            System.out.println("Vtak spi, nemoze mavat kridlami.");
        }
    }

    private void mavatkridlami(){
        System.out.println("Mavam teda lietam.");
    }
}
