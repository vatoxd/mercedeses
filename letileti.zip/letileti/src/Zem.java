import java.util.*;
import java.util.List;

public class Zem {
    private List<Tvor> tvorovia;

    public Zem() {
        this.tvorovia = new ArrayList<>();
    }
    public void addTvor(Tvor tvor) {
        this.tvorovia.add(tvor);
    }
    public List<Tvor> getTvorovia() {
        return tvorovia;
    }
    public void removeTvor(Tvor tvor) {
        this.tvorovia.remove(tvor);
    }

}
