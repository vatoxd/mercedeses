import java.util.List;

public class SynchronyFly <Type extends flyable> {
    private List<Type> tvory;

    public SynchronyFly(List<Type> tvory) {
        this.tvory = tvory;
    }

    public void startFlying(){
        for (Type tvory : tvory) {
            tvory.fly();
        }
    }

}
