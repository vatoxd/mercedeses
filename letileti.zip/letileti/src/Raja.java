public class Raja extends Tvor implements flyable{
    @Override
    public void fly() {
        System.out.println("Som raja a letim.");
    }

}
