public interface shineable {
    void shine();
}
