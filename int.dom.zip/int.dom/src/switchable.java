public interface switchable {
    void switch_device();
}
