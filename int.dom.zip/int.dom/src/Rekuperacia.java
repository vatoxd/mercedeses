public class Rekuperacia extends Device implements switchable {
    private static Rekuperacia instance; //Singleton

    private Rekuperacia() {
        setLocation(INHOMELOC.TECHNICKA);
        System.out.println("Rekuperácia umiestnená v technickej miestnosti.");
    }

    public static Rekuperacia getInstance() {
        if (instance == null) {
            instance = new Rekuperacia();
        }
        return instance;
    }

    @Override
    public void setLocation(INHOMELOC room) {
        System.out.println("Rekuperácia bola umiestnená do: " + room);
    }

    @Override
    public void switch_device(){
        if (isOn()){
            turn_off();
        } else {
            turn_on();
        }
    }
}