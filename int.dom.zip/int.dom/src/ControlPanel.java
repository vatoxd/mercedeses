import java.util.List;

public class ControlPanel <Type extends switchable> {
    private List<Type> devices; //type na ulozenie zoznamu objektov

    public ControlPanel(List<Type> devices) {
        this.devices = devices;
    }

    public void switchAll(){
        for (Type device : devices) { //slucka for
            device.switch_device();
        }
    }
}
