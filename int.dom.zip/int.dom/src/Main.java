import java.util.*;
public class Main {
    public static void main(String[] args) {
        Dom dom = new Dom(); // objekt triedy Dom

        Light svetlo1 = new Light(INHOMELOC.CHODBA);
        Light svetlo2 = new Light(INHOMELOC.SPALNA);
        Light svetlo3 = new Light(INHOMELOC.OBYVACKA);

        dom.addDevice(svetlo1); //pridanie svetiel do zoznamu
        dom.addDevice(svetlo2);
        dom.addDevice(svetlo3);

        Rekuperacia rekuperacia = Rekuperacia.getInstance(); // pridanie rekuperacie do zoznamu
        dom.addDevice(rekuperacia);

        Device[] devicesArray = new Device[dom.getDevices().size()];
        devicesArray = dom.getDevices().toArray(devicesArray);

        List<switchable> switchableDevices = new ArrayList<>();
        for (Device device : devicesArray) {
            if (device instanceof switchable) {
                switchableDevices.add((switchable) device);
            }
        }
        ControlPanel<switchable> controlPanel = new ControlPanel<>(switchableDevices);
        controlPanel.switchAll();
    }
}