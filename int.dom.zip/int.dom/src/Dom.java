import java.util.*;

public class Dom {
    private List<Device> devices;

    public Dom() { //parametricky konstruktor
        devices = new ArrayList<>();
    }

    public void addDevice(Device device) {
        devices.add(device);
    }

    public void removeDevice(Device device) {
        devices.remove(device);
    }

    public List<Device> getDevices() {
        return devices;
    }
}
