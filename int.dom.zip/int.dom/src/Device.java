public abstract class Device { //abstract

    private boolean isOn; //private boolean isOn
    private INHOMELOC location; // private INHOMELOC location

    public boolean isOn() {
        return isOn;
    }

    public void turn_on(){
        isOn = true;
        System.out.println("Zariadenie bolo zapnute.");
    }

    public void turn_off(){
        isOn = false;
        System.out.println("Zariadenie bolo vypnute.");
    }

    public void setLocation(INHOMELOC room){ //clenska metoda
        this.location = room;
    }

    public INHOMELOC getLocation(){
        return location;
    }
}
