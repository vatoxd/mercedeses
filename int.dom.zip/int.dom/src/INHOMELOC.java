public enum INHOMELOC {
    PREDSIEN,
    CHODBA,
    OBYVACKA,
    KUCHYNA,
    WC,
    KUPELNA,
    SPALNA,
    DETSKAIZBA,
    HOSTOVSKA,
    TECHNICKA
}
