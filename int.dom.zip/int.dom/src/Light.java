public class Light extends Device implements shineable, switchable {
    public Light(INHOMELOC room) { //parametricky konstruktor, kt bude parameter prijimat ako INHOMELOC
        setLocation(room);
    }

    @Override
    public void setLocation(INHOMELOC room) { //nadradena trieda override
        System.out.println("Svetlo bolo umiestnené do: " + room);
    }

    @Override
    public void shine(){
        if (!isOn()){
            turn_on();
        }
        System.out.println("Svietim");
    }

    @Override
    public void switch_device(){
        if (isOn()){
            turn_off();
        } else {
            turn_on();
        }
    }
}
