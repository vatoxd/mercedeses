package vesmir;

import java.time.LocalDate;

public abstract class VesmirneTeleso {
    protected String meno;
    protected LocalDate datumVzniku;


    public VesmirneTeleso(String meno) {
        this.meno = meno;
        this.datumVzniku = LocalDate.now();
    }


    public void vznik() {
        System.out.println("Teleso " + meno + " vzniklo dňa " + datumVzniku);
    }


    public abstract void zanik();
}

