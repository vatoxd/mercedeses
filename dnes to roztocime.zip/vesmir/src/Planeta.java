package vesmir;

public class Planeta extends VesmirneTeleso implements Rotable {
    private String meno;


    public Planeta(String meno) {
        super(meno);
        this.meno = meno;
    }


    @Override
    public void rotate() {
        System.out.println("Planeta " + meno + " sa rotuje.");
    }

    @Override
    public void zanik() {
        System.out.println("Planeta " + meno + " sa rozlúčila.");
    }

    @Override
    public String toString() {
        return "Planeta: " + meno;
    }
}

