package vesmir;

import java.util.ArrayList;
import java.util.List;

public class Universe {
    private static Universe instance;
    private List<VesmirneTeleso> telesa;


    private Universe() {
        telesa = new ArrayList<>();
    }


    public static Universe getInstance() {
        if (instance == null) {
            instance = new Universe();
        }
        return instance;
    }


    public void pridajTeleso(VesmirneTeleso teleso) {
        telesa.add(teleso);
    }


    public void odstranTeleso(VesmirneTeleso teleso) {
        telesa.remove(teleso);
    }


    public void zobrazTelesa() {
        for (VesmirneTeleso teleso : telesa) {
            System.out.println(teleso);
        }
    }
}
