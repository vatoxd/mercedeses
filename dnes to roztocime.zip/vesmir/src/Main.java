package vesmir;

public class Main {
    public static void main(String[] args) {

        Universe universe = Universe.getInstance();


        Hviezda slnko = new Hviezda("Slnko");
        Planeta zem = new Planeta("Zem");
        Planeta mars = new Planeta("Mars");
        Planeta venusa = new Planeta("venusa");

        universe.pridajTeleso(slnko);
        universe.pridajTeleso(zem);
        universe.pridajTeleso(mars);
        universe.pridajTeleso(venusa);

        System.out.println("Telesá v vesmíre:");
        universe.zobrazTelesa();

        slnko.pridajObiehajuceTeleso(zem);
        slnko.pridajObiehajuceTeleso(mars);
        slnko.pridajObiehajuceTeleso(venusa);

        System.out.println("\nRoztáčanie hviezdy a obiehajúcich telies:");
        Roztocenie<Rotable> roztocenie = new Roztocenie<>();
        roztocenie.pridajTeleso(slnko);
        roztocenie.pridajTeleso(zem);
        roztocenie.pridajTeleso(mars);
        roztocenie.roztocVesmir();
    }
}
