package vesmir;

import java.util.ArrayList;
import java.util.List;

public class Hviezda extends VesmirneTeleso implements Rotable {
    private String meno;
    private List<VesmirneTeleso> obiehajuceTelesa;

    public Hviezda(String meno) {
        super(meno);
        this.meno = meno;
        this.obiehajuceTelesa = new ArrayList<>();
    }


    @Override
    public void rotate() {
        System.out.println("Hviezda " + meno + " sa rotuje.");
    }


    public void pridajObiehajuceTeleso(VesmirneTeleso teleso) {
        obiehajuceTelesa.add(teleso);
        System.out.println(teleso + " začalo obiehať hviezdu " + meno);
    }

    @Override
    public void zanik() {
        System.out.println("Hviezda " + meno + " zanikla.");
    }

    @Override
    public String toString() {
        return "Hviezda: " + meno;
    }

    public List<VesmirneTeleso> getObiehajuceTelesa() {
        return obiehajuceTelesa;
    }
}
