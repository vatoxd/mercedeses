package vesmir;

public class Kometa extends VesmirneTeleso implements Rotable {
    public Kometa(String meno) {
        super(meno);
    }

    @Override
    public void rotate() {
        System.out.println("Kometa " + super.meno + " sa začína točiť!");
    }

    @Override
    public void zanik() {
        System.out.println("Kometa " + super.meno + " vybuchla!");
    }
}
