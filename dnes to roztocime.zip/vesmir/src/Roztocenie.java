package vesmir;

import java.util.ArrayList;
import java.util.List;

public class Roztocenie<Type extends Rotable> {
    private List<Type> telesa;

    public Roztocenie() {
        telesa = new ArrayList<>();
    }


    public void pridajTeleso(Type teleso) {
        telesa.add(teleso);
    }


    public void roztocVesmir() {
        for (Type teleso : telesa) {
            teleso.rotate();
        }
    }
}

