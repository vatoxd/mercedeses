package vesmir;

public interface Rotable {
    void rotate();
}
