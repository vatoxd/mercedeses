package vesmir;

public class Hmlovina implements Rotable {
    private String meno;

    public Hmlovina(String meno) {
        this.meno = meno;
    }

    @Override
    public void rotate() {
        System.out.println("Hmlovina " + meno + " sa začína točiť!");
    }
}

