public class Main {
    public static void main(String[] args) {
        Car car = new Car();
        StarterUnit<startable> starter = StarterUnit.getInstance();

        for (startable component : car.components) {
            starter.registerComponent(component);
        }

        starter.startAll();
        starter.stopAll();
    }
}