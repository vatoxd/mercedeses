public interface diagnosable {
    // Funkcia na diagnostiku
    void diagnose();
}
