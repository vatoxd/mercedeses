// Abstraktná trieda Suciastka
abstract class Suciastka {
    // Polohovanie súčiastky vo vozidle
    private VEHI_POSITION position;

    // Abstraktná metóda na pripojenie súčiastky
    public abstract void connect();

    // Abstraktná metóda na odobratie súčiastky
    public abstract void remove();

    // Nastavenie polohy súčiastky
    public void setPosition(VEHI_POSITION position) {
        this.position = position;
    }

    // Získanie aktuálnej polohy súčiastky
    public VEHI_POSITION getPosition() {
        return position;
    }
}