//Trieda Car
class Car {
    public startable[] components;

    public Car() {
        components = new startable[]{
                new Engine(VEHI_POSITION.FRONT_AREA),
                new GearBox(),
                new Brake_system(),
                new Wheel(), new Wheel(), new Wheel(), new Wheel()
        };
    }
}
