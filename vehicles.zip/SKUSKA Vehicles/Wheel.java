// Trieda Wheel
public class Wheel extends Suciastka implements diagnosable, startable {
    private VEHI_POSITION position;
    private boolean isRotating;

    @Override
    public void connect() {

    }

    @Override
    public void remove() {

    }

    @Override
    public void setPosition(VEHI_POSITION posi) {
        this.position = posi;
    }


    @Override
    public void start() {
        isRotating = true;
        System.out.println("Koleso sa začalo točiť.");
    }

    @Override
    public void stop() {
        isRotating = false;
        System.out.println("Koleso sa zastavilo.");
    }

    @Override
    public void diagnose() {

    }
}