// Trieda Engine
class Engine extends Suciastka implements diagnosable, startable {
    private boolean isRunning;
    private VEHI_POSITION position;

    public Engine(VEHI_POSITION position) {
        setPosition(position);
    }

    @Override
    public void setPosition(VEHI_POSITION posi) {
        this.position = posi;
    }


    @Override
    public void start() {
        if (!isRunning) {
            isRunning = true;
            System.out.println("Motor bol naštartovaný.");
        } else {
            System.out.println("Motor už beží.");
        }
    }

    @Override
    public void stop() {
        if (isRunning) {
            isRunning = false;
            System.out.println("Motor bol vypnutý.");
        } else {
            System.out.println("Motor už je vypnutý.");
        }
    }

    @Override
    public void connect() {

    }

    @Override
    public void remove() {

    }

    @Override
    public void diagnose() {

    }
}