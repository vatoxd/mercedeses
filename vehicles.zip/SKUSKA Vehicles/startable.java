public interface startable {
    // Funkcia na spustenie
    void start();

    // Funkcia na zastavenie
    void stop();
}
