// Trieda Brake_system
class Brake_system extends Suciastka implements diagnosable, startable {
    private boolean isEngaged;

    @Override
    public void connect() {

    }

    @Override
    public void remove() {

    }

    @Override
    public void setPosition(VEHI_POSITION posi) {}


    @Override
    public void start() {
        isEngaged = true;
        System.out.println("Brzdy aktivované.");
    }

    @Override
    public void stop() {
        isEngaged = false;
        System.out.println("Brzdy uvoľnené.");
    }

    @Override
    public void diagnose() {

    }
}