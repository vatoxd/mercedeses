import java.util.ArrayList;
import java.util.List;

// Generická Singleton trieda StarterUnit
class StarterUnit<T extends startable> {
    private static StarterUnit instance;
    private List<T> components;

    private StarterUnit() {
        components = new ArrayList<>();
    }

    public static synchronized StarterUnit getInstance() {
        if (instance == null) {
            instance = new StarterUnit();
        }
        return instance;
    }

    public void registerComponent(T component) {
        components.add(component);
    }

    public void startAll() {
        for (T component : components) {
            component.start();
        }
    }

    public void stopAll() {
        for (T component : components) {
            component.stop();
        }
    }
}