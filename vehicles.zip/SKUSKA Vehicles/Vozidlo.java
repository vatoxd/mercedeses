import java.util.ArrayList;
import java.util.List;

// Trieda Vozidlo
class Vozidlo {
    // Zoznam súčiastok, z ktorých je vozidlo zložené
    private List<Suciastka> suciastky;

    // Neparametrický konštruktor inicializujúci zoznam súčiastok
    public Vozidlo() {
        suciastky = new ArrayList<>();
    }

    // Funkcia na pridanie súčiastky do zoznamu
    public void pridatSuciastku(Suciastka suciastka) {
        suciastky.add(suciastka);
    }

    // Funkcia na odobratie súčiastky zo zoznamu
    public void odstranitSuciastku(Suciastka suciastka) {
        suciastky.remove(suciastka);
    }

    // Funkcia na výpis všetkých súčiastok
    public void vypisSuciastky() {
        for (Suciastka suciastka : suciastky) {
            System.out.println(suciastka.getClass().getSimpleName() + " - Pozícia: " + suciastka.getPosition());
        }
    }
}