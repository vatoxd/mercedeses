// Enumerátor VEHI_POSITION definujúci polohu súčiastok vo vozidle
enum VEHI_POSITION {
    CABIN,
    FRONT_AREA,
    REAR_AREA
}
