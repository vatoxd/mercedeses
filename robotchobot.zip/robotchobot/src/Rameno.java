public class Rameno extends Suciastka implements diagnosable, movable{
    public Rameno(DEVQUALITY quality) {
        setQuality(quality);
    }

    @Override
    public void setQuality(DEVQUALITY quality) {
        super.setQuality(quality);
    }

    @Override
    public void diagnose() {
        System.out.println("Diagnostika Ramena");
    }

    @Override
    public void move(int dx, int dy, int dz){
        System.out.println("Rameno sa hybe.");
    }

    @Override
    public void connect(){
        System.out.println("Rameno je pripojene.");
    }

    @Override
    public void disconnect(){
        System.out.println("Rameno je odpojene.");
    }
}
