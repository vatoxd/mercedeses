import java.util.*;
public class DiagnoseUnit <Type extends diagnosable> {
    private static DiagnoseUnit instance; //singleton

    private List<Type> devices = new ArrayList<>();

    public static synchronized DiagnoseUnit getInstance() {
        if (instance == null) {
            instance = new DiagnoseUnit();
        }
        return instance;
    }

    public void diagnoseAll(){
        for (Type device : devices) {
            device.diagnose();
        }
    }

    public void addDevice(Type device) {
        devices.add(device);
    }
    public void removeDevice(Type device) {
        devices.remove(device);
    }

}
