public class Noha extends Suciastka implements diagnosable, movable {
    public Noha(DEVQUALITY quality) {
        setQuality(quality);
    }

    @Override
    public void diagnose() {
        System.out.println("Diagnostika nohy.");
    }

    @Override
    public void connect(){
        System.out.println("Noha pripojena.");
    }

    @Override
    public void disconnect(){
        System.out.println("Noha odpojena.");
    }

    @Override
    public void move(int dx, int dy, int dz){
        System.out.println("Noha sa pohla o " + dx + " " + dy + " " + dz);
    }

}
