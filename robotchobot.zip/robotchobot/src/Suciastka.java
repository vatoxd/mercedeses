public abstract class Suciastka {
    public abstract void connect(); // abstraktne metody
    public abstract void disconnect();

    private DEVQUALITY quality;

    public void setQuality(DEVQUALITY quality) {
        this.quality = quality;
    }

    public DEVQUALITY getQuality() {
        return quality;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + quality;
    }
}
