public interface diagnosable {
    void diagnose();
}
