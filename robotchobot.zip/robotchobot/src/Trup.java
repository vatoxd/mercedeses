public class Trup extends Suciastka implements diagnosable{
    public Trup(DEVQUALITY quality){
        setQuality(quality);
    }

    @Override
    public void diagnose() {
        System.out.println("Diagnostika trupu");
    }

    @Override
    public void connect(){
        System.out.println("Trup pripojeny");
    }

    @Override
    public void disconnect(){
        System.out.println("Trup odpojeny");
    }
}
