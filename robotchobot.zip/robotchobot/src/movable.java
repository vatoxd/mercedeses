public interface movable {
    void move(int dx, int dy, int dz);
}
