import java.util.*;

public class Robot {
    private List<Suciastka> suciastky;

    public Robot() {
        suciastky = new ArrayList<>();
    }
    public void addSuciastka(Suciastka suciastka) {
        suciastky.add(suciastka);
    }

    public void removeSuciastka(Suciastka suciastka) {
        suciastky.remove(suciastka);
    }

    public List<Suciastka> getSuciastky() {
        return suciastky;
    }

    public void vypisSuciastky() {
        System.out.println("Súčiastky robota:");
        for (Suciastka suciastka : suciastky) {
            System.out.println("- " + suciastka.toString());
        }
    }
}
