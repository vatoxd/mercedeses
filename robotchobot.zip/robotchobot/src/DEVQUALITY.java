public enum DEVQUALITY {
    FIRST,
    SECOND,
    THIRD,
    UNDEFINED
}
