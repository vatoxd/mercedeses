public class Main {
    public static void main(String[] args) {
        Robot robot = new Robot();

        Hlava hlava = new Hlava(DEVQUALITY.FIRST);
        Trup trup = new Trup(DEVQUALITY.SECOND);
        Noha noha1 = new Noha(DEVQUALITY.THIRD);
        Noha noha2 = new Noha(DEVQUALITY.THIRD);
        Rameno rameno1 = new Rameno(DEVQUALITY.SECOND);
        Rameno rameno2 = new Rameno(DEVQUALITY.SECOND);

        robot.addSuciastka(hlava);
        robot.addSuciastka(trup);
        robot.addSuciastka(noha1);
        robot.addSuciastka(noha2);
        robot.addSuciastka(rameno1);
        robot.addSuciastka(rameno2);

        robot.vypisSuciastky();

        DiagnoseUnit diagnoseUnit = DiagnoseUnit.getInstance();
        for(Suciastka suciastka : robot.getSuciastky()){
            diagnoseUnit.addDevice((diagnosable)suciastka);
        }
        diagnoseUnit.diagnoseAll();
    }
}