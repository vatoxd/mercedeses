public class Hlava extends Suciastka implements diagnosable, movable{
    public Hlava(DEVQUALITY quality) {
        setQuality(quality);
    }

    @Override
    public void diagnose() {
        System.out.println("Diagnostika hlavy.");
    }

    @Override
    public void connect(){
        System.out.println("Hlava pripojena.");
    }

    @Override
    public void disconnect(){
        System.out.println("Hlava odpojena.");
    }

    @Override
    public void move(int dx, int dy, int dz){
        System.out.println("Noha sa pohla o " + dx + " " + dy + " " + dz);
    }
}
